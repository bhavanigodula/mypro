using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DhruvaOverseas.Pages.Students
{
    public class TestsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
