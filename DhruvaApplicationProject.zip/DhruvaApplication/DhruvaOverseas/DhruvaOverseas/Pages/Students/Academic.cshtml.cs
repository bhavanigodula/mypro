using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DhruvaOverseas.Pages.Students
{
    public class AcademicModel : PageModel
    {
        public class StudentInfo
        {
            public string sid;
            public string name;
            public string sname;
            public string mobile;
            public string amobile;
            public string email;
        }
        public StudentInfo studentInfo = new StudentInfo();
        public string errormessage = "";
        public string successmessage = "";
        public void OnGet()
        {
            string sid = Request.Query["sid"];


            try
            {
                string connectionstring = "Data Source=DESKTOP-2SPFC3N\\MYSQLSERVER;Initial Catalog=dhruva;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();
                    string sql = "select *from student where sid=@sid";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@sid", sid);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                StudentInfo studentInfos = new StudentInfo();
                                studentInfo.sid = reader.GetInt32(0).ToString();
                                studentInfo.name = reader.GetString(1);
                                studentInfo.sname = reader.GetString(2);
                                studentInfo.mobile = reader.GetString(3);
                                studentInfo.amobile = reader.GetString(4);
                                studentInfo.email = reader.GetString(5);
                                //tudentInfo.date = reader.GetDateTime(6);

                                // listStudents.Add(studentInfo);
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                errormessage = ex.Message;
                return;
            }
        }
    }
}
